# Enterprise Multi-Site Network Design

## Overview

This project demonstrates the design and implementation of a multi-site enterprise network using Cisco Packet Tracer.

The network consists of:

- Headquarters (HQ)
- Bandung Branch
- Jakarta Branch

## Technologies Used

- VLAN Segmentation
- Inter-VLAN Routing
- 802.1Q Trunking
- EtherChannel (LACP)
- Static Routing
- DHCP
- DNS
- NTP
- WEB Server
- SYSLOG

## Network Topology

![Topology](topology/topology-diagram.png)

## Validation Tests

### Test 1 - Inter-VLAN Routing

IT VLAN → HRD VLAN

### Test 2 - HQ to Bandung Connectivity

HQ → Bandung Branch

### Test 3 - HQ to Jakarta Connectivity

HQ → Jakarta Branch

### Test 4 - Inter-Branch Communication

Bandung → Jakarta

### Test 5 - Centralized Service Accessibility

Branch → HQ Services

## Project Outcome

✔ Inter-VLAN Routing Operational

✔ HQ ↔ Bandung Connected

✔ HQ ↔ Jakarta Connected

✔ Bandung ↔ Jakarta Connected

✔ Centralized Services Accessible